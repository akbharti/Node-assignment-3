const mysql = require('mysql');
const util = require('util');

  let con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root", 
    database: "info"
  });

   con.connect( (err) =>{
      if (err) throw err;
    });

    con.query = util.promisify(con.query)

      //Create parents info  
      exports.insertParentInfo =  async (firstName,lastName,age,contact,obj)=>{

        console.log (firstName,lastName,age,contact)
        
        let sqlParentInsert = `INSERT INTO parent (firstName,lastName,age,contact) VALUES ('${firstName}','${lastName}','${age}','${contact}')`;  
        
        try{
          results = await con.query(sqlParentInsert )
          console.log(JSON.stringify(results))
        }
        catch (err) {
        console.log(err)
      }

      let pid =  results.insertId
      console.log("pid ::" ,pid)

//children


      let childData = obj.childern;

      childData.forEach(childElement => {
        
        childFirstName = childElement.firstName;
        childLastName = childElement.lastName;
        childDob = childElement.dob;


        console.log(childFirstName,childLastName,childDob)

        let sqlChildInsert = `INSERT INTO children (pid,firstName,lastName,dob) VALUES ('${pid}','${childFirstName}','${childLastName}','${childDob}')`;  
        
        try{
         let childResults =  con.query(sqlChildInsert )
          console.log(JSON.stringify(childResults))
        }
        catch (err) {
        console.log(err)
      }

      let cid =  results.insertId
      console.log("cid :::",cid)

      // subject

      let subjects = childElement.subjects;
      console.log("subjects ::::::",subjects)

      subjects.forEach(subjectsElement => {

        paperName = subjectsElement.paperName;
        marks = subjectsElement.marks;

        console.log(cid, paperName,marks)

        let sqlSubjectInsert = `INSERT INTO subjects (cid,paperName,marks) VALUES (${cid},'${paperName}','${marks}')`;  

        try{
       let   subjectResults =  con.query(sqlSubjectInsert )
          console.log(JSON.stringify(subjectResults))
        }
        catch (err) {
        console.log(err)
      }

      })

      });

     }


    
     exports.parentID =  async (pid)=>{

      let sqlparent = `SELECT p.firstName,p.lastName,p.age, COUNT(c.pid) AS 'count'
      FROM parent p, children c 
      WHERE p.pid = ${pid} AND c.pid = ${pid}
      GROUP BY c.pid
      `;  
    
      con.query(sqlparent,   (err, result, fields)=> {
        if (err) 
          console.log(sqlparent);
        console.log(result);
      });
   
     }

     exports.children =  async (pid)=>{
       console.log(pid)

      let sqlChildren = `SELECT c.cid,c.firstName,c.lastname,c.dob
      FROM children c, parent p
      WHERE c.pid = p.pid 
      AND p.pid = ${pid}
      `;  
    
      con.query(sqlChildren,   (err, result, fields)=> {
        if (err) 
          console.log(sqlChildren);
        console.log(result);
      });
   
     }

     4
     exports.subject =  async (cid)=>{
      console.log(cid)

     let sqlSubject = `SELECT c.cid,s.papername,s.marks
     FROM children c, subjects s
     WHERE s.cid = c.cid
     AND s.cid = ${cid}
     `;  
   
     con.query(sqlSubject,   (err, result, fields)=> {
       if (err) 
         console.log(sqlSubject);
       console.log(result);
     });
  
    }

   //  5
     exports.childrenList =  async (paperName)=>{
      console.log(paperName)

     let sqlChildrenList = `SELECT p.firstName,c.firstName,s.papername
     FROM parent p,children c, subjects s
     WHERE p.pid = c.pid AND c.cid = s.cid AND s.paperName = ${paperName}
     `;  
   
     con.query(sqlChildrenList,   (err, result, fields)=> {
       if (err) 
         console.log(sqlChildrenList);
       console.log(result);
     });
  
     }